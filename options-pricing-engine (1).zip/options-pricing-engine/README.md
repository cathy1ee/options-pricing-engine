# Options Pricing Engine (C++)

Prices European calls and puts two ways, closed-form **Black-Scholes** and **Monte Carlo** simulation, and checks them against each other.

- Closed-form price and all five Greeks (Delta, Gamma, Vega, Theta, Rho)
- Monte Carlo pricer under geometric Brownian motion, with a standard error on every estimate
- **Antithetic variates** for variance reduction (each draw `Z` is paired with `-Z`)
- Test suite: textbook value, put-call parity, analytic Greeks vs finite differences, Monte Carlo vs Black-Scholes
- Benchmark: Monte Carlo convergence rate, variance reduction, and speed

## Build and run

```bash
make test    # 1,562 checks across 240 option configurations
make bench   # convergence + speed benchmark
```

Requires a C++17 compiler (`g++` or `clang++`). No external dependencies.

## Results

Benchmark for an at-the-money 1-year call (S=K=100, r=5%, vol=20%). Black-Scholes price is 10.4506. RMSE is measured over 20 independent seeds. Timings are from a single core with `-O2`.

| Paths | Method | RMSE vs Black-Scholes | Error (% of price) | Time |
|---:|---|---:|---:|---:|
| 1,000 | plain | 0.370 | 3.54% | 0.05 ms |
| 10,000 | plain | 0.151 | 1.45% | 0.45 ms |
| 100,000 | plain | 0.048 | 0.46% | 4.6 ms |
| 1,000,000 | plain | 0.0117 | 0.11% | 46 ms |
| 1,000,000 | antithetic | 0.0100 | 0.10% | 29 ms |
| 10,000,000 | antithetic | 0.0032 | 0.03% | 293 ms |

- **Convergence:** the slope of log(error) against log(paths) is **-0.47**. Theory predicts -0.5, because Monte Carlo error shrinks like 1/√N. So 100× more paths gives about 10× less error.
- **Variance reduction:** antithetic variates cut estimator variance by **~50%** at 1M paths, which means the same accuracy with about half the samples. They are also about 1.6× faster, because each normal draw is used twice.
- **Closed form:** about **20M prices per second** (≈50 ns each).
- **Tests:** 1,562/1,562 pass. The largest gap between an analytic Greek and its finite-difference check is 1.4e-5.

## How it works

**Black-Scholes** (`src/black_scholes.cpp`)

```
d1 = [ln(S/K) + (r + σ²/2)T] / (σ√T)        d2 = d1 − σ√T
Call = S·N(d1) − K·e^(−rT)·N(d2)            Put = K·e^(−rT)·N(−d2) − S·N(−d1)
```

The normal CDF is computed with `erfc`. Each Greek is the analytic derivative of the price. For example, Delta is N(d1) for a call, and Gamma = φ(d1) / (Sσ√T) is the same for calls and puts.

**Monte Carlo** (`src/monte_carlo.cpp`). Under the risk-neutral measure, the terminal price is
`S_T = S·exp((r − σ²/2)T + σ√T·Z)` with `Z ~ N(0,1)`. The pricer simulates N values of `S_T`, averages the payoff, and discounts it by `e^(−rT)`. The standard error is `stdev(payoff) / √N`.

**Antithetic variates:** for every `Z` the pricer also uses `−Z` and averages the two payoffs. The two results are negatively correlated, so their average has lower variance than two independent draws would.

**Tests** (`tests/test_pricing.cpp`)
1. Matches Hull's textbook example (call 4.76, put 0.81).
2. Put-call parity `C − P = S − K·e^(−rT)` holds to 1e-10.
3. Each analytic Greek matches a central finite difference, for example `Delta ≈ [V(S+h) − V(S−h)] / 2h`.
4. The Monte Carlo price falls within 4 standard errors of Black-Scholes.

## Project layout

```
include/pricing.hpp        option struct, function declarations
src/black_scholes.cpp      closed-form price + Greeks
src/monte_carlo.cpp        Monte Carlo pricer with antithetic variates
tests/test_pricing.cpp     correctness tests
bench/convergence.cpp      convergence, variance reduction and speed benchmark
```

## Possible extensions
- Control variates, using the Black-Scholes price of a correlated instrument
- American options with a binomial tree or Longstaff-Schwartz
- Implied volatility solved with Newton-Raphson on Vega
- Multithreading the Monte Carlo loop
